using Android.System;
using UnityEngine;

namespace Kart;

public class ModKart
{
    public  static UnityEngine $untity;


        public override getName(string $name)
    {
        return untity::getName($name);
    }

   public override string getDisplayName(string name)
    {
    
    }
}